﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WolfAgent : Agent {

	public Terrain terrain;

    TerrainData terrainData;
    //TerrainCollider terrainCollider;
    Bounds terrainBounds;

	PredatorPreyAcademy academy;

	public GameObject goal;

	// Detects when the block touches the goal.
	[HideInInspector]
	public PreyDetect goalDetect;

	Rigidbody agentRB;
	RayPerception rayPer;

	void Awake()
	{
		// There is one brain in the scene so this should find our brain.
		brain = FindObjectOfType<Brain>();
		academy = FindObjectOfType<PredatorPreyAcademy>();
	}

	public override void InitializeAgent()
	{
		base.InitializeAgent();
		goalDetect = GetComponent<PreyDetect>();
		goalDetect.agent = this;
		rayPer = GetComponent<RayPerception>();

		// Cache the agent rigidbody
		agentRB = GetComponent<Rigidbody>();

        // Get the ground's bounds
        terrainData = terrain.terrainData;
        terrainBounds = terrainData.bounds;
	}

	public override void CollectObservations()
	{
		float rayDistance = 50f;
		float[] rayAngles = { 30f, 45f, 90f, 135f, 150f, 110f, 70f };
		string[] detectableObjects;
		detectableObjects = new string[] {"goal", "obstacle" };
		AddVectorObs(rayPer.Perceive(rayDistance, rayAngles, detectableObjects, 0f, 0f));
		AddVectorObs(rayPer.Perceive(rayDistance, rayAngles, detectableObjects, 1.5f, 0f));
        
	}

	/// <summary>
	/// Use the ground's bounds to pick a random spawn position.
	/// </summary>
	public Vector3 GetRandomSpawnPos()
	{
		bool foundNewSpawnLocation = false;
		Vector3 randomSpawnPos = Vector3.zero;
		while (foundNewSpawnLocation == false)
		{
            float randomPosX = Random.Range(terrainBounds.min.x, terrainBounds.max.x);

            float randomPosZ = Random.Range(terrainBounds.min.z, terrainBounds.max.z);

            randomSpawnPos = new Vector3(randomPosX, 5f, randomPosZ);
			if (Physics.CheckBox(randomSpawnPos, new Vector3(2.5f, 0.01f, 2.5f)) == false)
			{
				foundNewSpawnLocation = true;
			}
		}
        /*
        Debug.Log("terrainBounds.min.x= " + terrainBounds.min.x);
        Debug.Log("terrainBounds.max.x= " + terrainBounds.max.x);

        Debug.Log("terrainBounds.min.z= " + terrainBounds.min.z);
        Debug.Log("terrainBounds.max.z= " + terrainBounds.max.z);


        Debug.Log("randomSpawnPos.x= " + randomSpawnPos.x);
        Debug.Log("randomSpawnPos.y= " + randomSpawnPos.y);
        Debug.Log("randomSpawnPos.z= " + randomSpawnPos.z);
        */
        return randomSpawnPos;
	}

	/// <summary>
	/// Called when the agent touches the prey.
	/// </summary>
	public void IScoredAGoal()
	{
		// We use a reward of 5.
		AddReward(5f);

		// By marking an agent as done AgentReset() will be called automatically.
		Done();
	}

	/// <summary>
	/// Moves the agent according to the selected action.
	/// </summary>
	public void MoveAgent(float[] act)
	{

		Vector3 dirToGo = Vector3.zero;
		Vector3 rotateDir = Vector3.zero;

		int action = Mathf.FloorToInt(act[0]);

		switch (action)
		{
		case 0:
			dirToGo = transform.forward * 1f;
            //rotateDir = transform.up * 1f;
                break;
		case 1:
			dirToGo = transform.forward * -1f;
			break;
		case 2:
			rotateDir = transform.up * 1f;
			break;
		case 3:
			rotateDir = transform.up * -1f;
			break;
        case 4: //Do nothing
            break;
		}
		transform.Rotate(rotateDir, Time.fixedDeltaTime * 200f);
		agentRB.AddForce(dirToGo * academy.agentRunSpeed,
			ForceMode.VelocityChange);

	}

	/// <summary>
	/// Called every step of the engine. Here the agent takes an action.
	/// </summary>
	public override void AgentAction(float[] vectorAction, string textAction)
	{
		// Move the agent using the action.
		MoveAgent(vectorAction);
	}

	/// <summary>
	/// In the editor, if "Reset On Done" is checked then AgentReset() will be 
	/// called automatically anytime we mark done = true in an agent script.
	/// </summary>
	public override void AgentReset()
	{

		transform.position = GetRandomSpawnPos();
		agentRB.velocity = Vector3.zero;
		agentRB.angularVelocity = Vector3.zero;
	}
		
}
